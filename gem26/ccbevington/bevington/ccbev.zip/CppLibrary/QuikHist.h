//
//  QuikHist.h
//
#include<stdio.h>
#include <math.h>

void HistSetup(float Hbot,float Hint, float Htop);
void Histogram(float x);
void HistStats(char title[]);
void HistDisplay(char title[]);
